// hunter-------------------------------------
// @file      : plugin.go
// @author    : hyy19
// @contact   : xxx@qq.com
// @time      : 2025/8/8 xx:xx
// -------------------------------------------

package plugin

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"github.com/Autumn-27/ScopeSentry-Scan/internal/options"
	"github.com/Autumn-27/ScopeSentry-Scan/internal/types"
	"github.com/Autumn-27/ScopeSentry-Scan/pkg/utils"
	"net"
	"net/url"
	"strconv"
	"strings"
	"time"
)

func GetName() string {
	return "hunter"
}

func Install() error {
	return nil
}

func Check() error {
	return nil
}

func Uninstall() error {
	return nil
}

var (
	APIKEY = "" // 请替换为实际 Hunter API 密钥
)

type HunterAsset struct {
	IsRisk         string `json:"is_risk"`
	URL            string `json:"url"`
	IP             string `json:"ip"`
	Port           int    `json:"port"`
	WebTitle       string `json:"web_title"`
	Domain         string `json:"domain"`
	IsRiskProtocol string `json:"is_risk_protocol"`
	Protocol       string `json:"protocol"`
	BaseProtocol   string `json:"base_protocol"`
	StatusCode     int    `json:"status_code"`
	//Component      *string `json:"component"` // null 值用指针处理
	OS        string `json:"os"`
	Company   string `json:"company"`
	Number    string `json:"number"`
	Country   string `json:"country"`
	Province  string `json:"province"`
	City      string `json:"city"`
	UpdatedAt string `json:"updated_at"` // 或 time.Time
	IsWeb     string `json:"is_web"`
	AsOrg     string `json:"as_org"`
	ISP       string `json:"isp"`
	Banner    string `json:"banner"`
	VulList   string `json:"vul_list"` // 实际可视为 string 或 []string，看数据而定
	Header    string `json:"header"`
}

type Response struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    struct {
		AccountType string        `json:"account_type"`
		Total       int           `json:"total"`
		Time        int           `json:"time"`
		Arr         []HunterAsset `json:"arr"`
	} `json:"data"`
}

func getFirstResolvedIP(domain string) (string, error) {
	ips, err := net.LookupIP(domain)
	if err != nil {
		return "", err
	}

	if len(ips) == 0 {
		return "", fmt.Errorf("没有找到解析的 IP")
	}

	// 返回第一个 IP 地址
	return ips[0].String(), nil
}
func isIP(address string) bool {
	return net.ParseIP(address) != nil
}

func handleHunterQuery(query string, page int, APIKEY, encodedStartTime, encodedEndTime string, op options.PluginOption) (int, error) {
	encoded := base64.URLEncoding.EncodeToString([]byte(query))
	urlRaw := fmt.Sprintf(
		// 	&status_code=200 干掉
		//	&is_web=0	即web(1) 非web(2)	都要
		"https://hunter.qianxin.com/openApi/search?api-key=%v&search=%v&page=%v&page_size=100&is_web=0&start_time=%v&end_time=%v",
		APIKEY, encoded, page, encodedStartTime, encodedEndTime,
	)

	op.Log(fmt.Sprintf("Request URL: %v", urlRaw), "d")
	var result Response
	for {
		res, err := utils.Requests.HttpGetByte(urlRaw)
		if err != nil {
			op.Log(fmt.Sprintf("get target %v error: %v", query, err), "w")
			//return 0, err		//此处不直接返回	如果超时重跑
		}

		op.Log(fmt.Sprintf("Response: %v", string(res)), "d")

		reader := bytes.NewReader(res)
		decoder := json.NewDecoder(reader)

		if err := decoder.Decode(&result); err != nil {
			op.Log(fmt.Sprintf("get target %v json decode error: %v", query, err), "w")
			return 0, err
		}

		//{"code":429,"data":null,"message":"请求太多啦，稍后再试试"}
		if result.Code != 200 {
			op.Log(fmt.Sprintf("get target %v result error code: %v message: %v", query, result.Code, result.Message), "w")
			fmt.Errorf("hunter API returned non-200 code: %v", result.Code)
			time.Sleep(2 * time.Second)
		}
		if result.Code == 200 {
			break
		}
	}

	op.Log(fmt.Sprintf("target search：%v hunter All size: %v search result: %v", query, len(result.Data.Arr), result.Message), "d")

	for _, r := range result.Data.Arr {
		//rawIp := r.IP
		//port := r.Port
		//host := r.Domain + ":" + strconv.Itoa(r.Port)
		protocol := r.Protocol
		icp := r.Number
		assetHost := ""
		Host := ""
		if strings.Contains(r.URL, "http") {
			Host = strings.SplitN(r.URL, "://", 2)[1]
			assetHost = Host
			if strings.Contains(Host, ":") {
				assetHost = strings.SplitN(Host, ":", 2)[0]
			}
		} else {
			Host = r.IP
			assetHost = r.IP
			fmt.Println("字符串中不包含 'http'")
		}

		//判断是不是域名 是域名要重新解析ip
		if isIP(assetHost) {
		} else {
			//fmt.Printf("'%s' 是一个域名\n", assetHost)
			// 获取第一个解析的 IP
			ip, err := getFirstResolvedIP(assetHost)
			if err != nil {
				fmt.Printf("  域名解析错误: %v\n", err)
				continue
			} else {
				//fmt.Printf("  解析IP: %s\n", ip)
				r.IP = ip //替换ip
			}
		}

		if protocol == "http" || protocol == "https" {
			assetHttp := types.AssetHttp{
				Type:    "http",
				Port:    fmt.Sprintf("%d", r.Port),
				IP:      r.IP,
				Title:   r.WebTitle,
				URL:     r.URL,
				Service: protocol,
				Tags:    []string{"Hunter"},
			}
			assetHttp.Host = assetHost
			if icp != "" {
				assetHttp.Tags = append(assetHttp.Tags, fmt.Sprintf("icp:%v", icp))
			}
			//op.ResultFunc(assetHttp)
		} else {
			assetOther := types.AssetOther{
				Type:    "other",
				Service: protocol,
				Port:    fmt.Sprintf("%d", r.Port),
				IP:      r.IP,
				Tags:    []string{"Hunter"},
			}
			assetOther.Host = assetHost
			if icp != "" {
				assetOther.Tags = append(assetOther.Tags, fmt.Sprintf("icp:%v", icp))
			}
			//op.ResultFunc(assetOther)
		}

		//这个不能要 输入ip会导致不能端口扫描
		//subdomain := types.SubdomainResult{
		//	Host: assetHost,
		//	IP:   []string{r.IP},
		//	Tags: []string{"Hunter"},
		//}
		//op.ResultFunc(subdomain)

		// 构建端口信息-->探测端口类型-->httpx
		domainSkip := types.PortAlive{
			Host: assetHost,
			IP:   r.IP,
			Port: fmt.Sprintf("%d", r.Port),
		}
		op.ResultFunc(domainSkip)
	}

	return result.Data.Total, nil
}

// Execute 目标处理
func Execute(input interface{}, op options.PluginOption) (interface{}, error) {
	data, ok := input.(string)
	if !ok {
		return nil, nil
	}
	parameter := op.Parameter
	page_size := 15
	if parameter != "" {
		args, err := utils.Tools.ParseArgs(parameter, "page_size")
		if err != nil {
		} else {
			for key, value := range args {
				if value != "" {
					switch key {
					case "page_size":
						page_size, _ = strconv.Atoi(value)
					}
				}
			}
		}
	}

	if strings.Contains(data, ".") {
		// 处理域名或 IP 类型的目标
		data = strings.TrimPrefix(data, "http://")
		data = strings.TrimPrefix(data, "https://")
		var target string
		target = data
		// 查找 "*." 是否存在
		if strings.Contains(data, "*.") {
			// 查找 "*." 的位置
			startIndex := strings.Index(data, "*.") + len("*.")
			target = data[startIndex:]
		}
		target = "http://" + target
		parsedURL, err := url.Parse(target)
		if err != nil {
			op.Log(fmt.Sprintf("target %v parsedURL error: %v", data, err), "w")
			return nil, nil
		}
		tmpdata := strings.Split(parsedURL.Host, ":")
		target = tmpdata[0]
		ip := net.ParseIP(target)
		query := ""
		if ip != nil {
			query = fmt.Sprintf("ip=\"%s\"", target)
		} else {
			query = fmt.Sprintf("domain.suffix=\"%s\"", target)

			domain := "asdsadhsakhjvjgvghdhsagf." + target
			ips, err := net.LookupIP(domain)
			if err != nil {
				fmt.Printf("%s 查询失败: %v\n", domain, err)
			}
			if len(ips) == 0 {
				fmt.Printf("%s 没有解析记录\n", domain)
			} else { //泛解析直接退出
				op.Log(fmt.Sprintf("域名 %s 泛解析 解析到的 IP: %s", domain, ips[0]), "w")
				return nil, nil
			}
		}

		// 获取当前时间
		endTime := time.Now()
		// 计算一年前的时间（字符串拼接方式）
		startTimeStr := fmt.Sprintf("%d-%s", endTime.Year()-3, endTime.Format("01-02 15:04:05"))
		// 格式化结束时间为字符串
		endTimeStr := endTime.Format("2006-01-02 15:04:05")
		// URL编码
		encodedStartTime := url.QueryEscape(startTimeStr)
		encodedEndTime := url.QueryEscape(endTimeStr)

		op.Log(fmt.Sprintf("encodedEndTime: %v", encodedEndTime), "d")
		op.Log(fmt.Sprintf("query: %v", query), "d")

		if query != "" {
			total, err := handleHunterQuery(query, 1, APIKEY, encodedStartTime, encodedEndTime, op)
			time.Sleep(2 * time.Second)
			if err != nil {
				op.Log(fmt.Sprintf("handle hunter query error: %v", err.Error()), "w")
			}
			pages := (total + 99) / 100
			if pages > page_size {
				pages = page_size
			}
			if pages >= 2 {
				for i := 2; i <= pages; i++ {
					handleHunterQuery(query, i, APIKEY, encodedStartTime, encodedEndTime, op)
					time.Sleep(2 * time.Second)
				}
			}
		}
	} else {
		// 非域名ip类，比如公司名称
	}

	return nil, nil
}
