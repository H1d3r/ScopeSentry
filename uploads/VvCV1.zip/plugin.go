package plugin

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math/rand"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/Autumn-27/ScopeSentry-Scan/internal/options"
	"github.com/Autumn-27/ScopeSentry-Scan/internal/results"
	"github.com/Autumn-27/ScopeSentry-Scan/internal/types"
	"github.com/Autumn-27/ScopeSentry-Scan/pkg/logger"
	"github.com/Autumn-27/ScopeSentry-Scan/pkg/utils"
)

func GetName() string {
	return "quake"
}

func Install() error {
	return nil
}

func Check() error {
	return nil
}

func Uninstall() error {
	return nil
}

// 修改API-KEY
var APIKEY = []string{
	"xxxxxxxx",
}

// 是否为VIP
var IsVIP = false

type VipQuakeServiceInfo struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    []struct {
		Time      time.Time `json:"time"`
		Transport string    `json:"transport"`
		Service   struct {
			HTTP struct {
				HTMLHash string `json:"html_hash"`
				Favicon  struct {
					Hash     string `json:"hash"`
					Location string `json:"location"`
					Data     string `json:"data"`
				} `json:"favicon"`
				Robots          string   `json:"robots"`
				SitemapHash     string   `json:"sitemap_hash"`
				Server          string   `json:"server"`
				Body            string   `json:"body"`
				XPoweredBy      string   `json:"x_powered_by"`
				MetaKeywords    string   `json:"meta_keywords"`
				RobotsHash      string   `json:"robots_hash"`
				Sitemap         string   `json:"sitemap"`
				Path            string   `json:"path"`
				Title           string   `json:"title"`
				Host            string   `json:"host"`
				SecurityText    string   `json:"security_text"`
				StatusCode      int      `json:"status_code"`
				ResponseHeaders string   `json:"response_headers"`
				URL             []string `json:"http_load_url"`
				Icp             struct {
					Licence     string `json:"licence"`
					UpdateTime  string `json:"update_time"`
					IsExpired   bool   `json:"is_expired"`
					LeaderName  string `json:"leader_name"`
					Domain      string `json:"domain"`
					MainLicence struct {
						Licence string `json:"licence"`
						Unit    string `json:"unit"`
						Nature  string `json:"nature"`
					} `json:"main_licence"`
					ContentTypeName string `json:"content_type_name"`
					LimitAccess     bool   `json:"limit_access"`
				} `json:"icp"`
			} `json:"http"`
			Version  string `json:"version"`
			Name     string `json:"name"`
			Product  string `json:"product"`
			Banner   string `json:"banner"`
			Response string `json:"response"`
		} `json:"service"`
		Images     []interface{} `json:"images"`
		OsName     string        `json:"os_name"`
		Components []interface{} `json:"components"`
		Location   struct {
			DistrictCn  string    `json:"district_cn"`
			ProvinceCn  string    `json:"province_cn"`
			Gps         []float64 `json:"gps"`
			ProvinceEn  string    `json:"province_en"`
			CityEn      string    `json:"city_en"`
			CountryCode string    `json:"country_code"`
			CountryEn   string    `json:"country_en"`
			Radius      float64   `json:"radius"`
			DistrictEn  string    `json:"district_en"`
			Isp         string    `json:"isp"`
			StreetEn    string    `json:"street_en"`
			Owner       string    `json:"owner"`
			CityCn      string    `json:"city_cn"`
			CountryCn   string    `json:"country_cn"`
			StreetCn    string    `json:"street_cn"`
		} `json:"location"`
		Asn       int    `json:"asn"`
		Hostname  string `json:"hostname"`
		Domain    string `json:"domain"`
		Org       string `json:"org"`
		OsVersion string `json:"os_version"`
		IsIpv6    bool   `json:"is_ipv6"`
		IP        string `json:"ip"`
		Port      int    `json:"port"`
	} `json:"data"`
	Meta struct {
		Total        int    `json:"total"`
		PaginationID string `json:"pagination_id"`
	} `json:"meta"`
}

type CommonQuakeServiceInfo struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    []struct {
		Time      time.Time `json:"time"`
		Transport string    `json:"transport"`
		Service   struct {
			HTTP struct {
				HTMLHash     string `json:"html_hash"`
				Robots       string `json:"robots"`
				SitemapHash  string `json:"sitemap_hash"`
				Server       string `json:"server"`
				XPoweredBy   string `json:"x_powered_by"`
				MetaKeywords string `json:"meta_keywords"`
				Path         string `json:"path"`
				Title        string `json:"title"`
				Host         string `json:"host"`
				StatusCode   int    `json:"status_code"`
			} `json:"http"`
			Version  string `json:"version"`
			Name     string `json:"name"`
			Product  string `json:"product"`
			Banner   string `json:"banner"`
			Response string `json:"response"`
		} `json:"service"`
		Location struct {
			DistrictCn  string    `json:"district_cn"`
			ProvinceCn  string    `json:"province_cn"`
			Gps         []float64 `json:"gps"`
			ProvinceEn  string    `json:"province_en"`
			CityEn      string    `json:"city_en"`
			CountryCode string    `json:"country_code"`
			CountryEn   string    `json:"country_en"`
			Radius      float64   `json:"radius"`
			DistrictEn  string    `json:"district_en"`
			Isp         string    `json:"isp"`
			StreetEn    string    `json:"street_en"`
			Owner       string    `json:"owner"`
			CityCn      string    `json:"city_cn"`
			CountryCn   string    `json:"country_cn"`
			StreetCn    string    `json:"street_cn"`
		} `json:"location"`
		Hostname string `json:"hostname"`
		Domain   string `json:"domain"`
		IsIpv6   bool   `json:"is_ipv6"`
		IP       string `json:"ip"`
		Port     int    `json:"port"`
	} `json:"data"`
	Meta struct {
		Total        int    `json:"total"`
		PaginationID string `json:"pagination_id"`
	} `json:"meta"`
}

// Execute 目标处理
// 带*的目标 "*.example.com"
// 不带*的目标
func Execute(input interface{}, op options.PluginOption) (interface{}, error) {
	data, ok := input.(string)
	if !ok {
		return nil, nil
	}
	parameter := op.Parameter
	size := 100
	if parameter != "" {
		args, err := utils.Tools.ParseArgs(parameter, "size")
		if err != nil {
		} else {
			for key, value := range args {
				if value != "" {
					switch key {
					case "size":
						size, _ = strconv.Atoi(value)
					}
				}
			}
		}
	}
	var respBody = []byte{}
	if strings.Contains(data, ".") {
		data = strings.TrimPrefix(data, "http://")
		data = strings.TrimPrefix(data, "https://")
		var target string
		target = data
		// 域名或ip类
		// 查找 "*." 是否存在
		if strings.Contains(data, "*.") {
			// 查找 "*." 的位置
			startIndex := strings.Index(data, "*.") + len("*.")
			target = data[startIndex:]
		}
		target = "http://" + target
		parsedURL, err := url.Parse(target)
		if err != nil {
			op.Log(fmt.Sprintf("target %v parsedURL error: %v", data, err), "w")
			return nil, nil
		}
		tmpdata := strings.Split(parsedURL.Host, ":")
		target = tmpdata[0]
		ip := net.ParseIP(target)
		query := ""
		if ip != nil {
			query = fmt.Sprintf("ip:\"%s\"", target)
		} else {
			query = fmt.Sprintf("domain:\"%s\"", target)
		}
		if query != "" {
			respBody = SearchQuakeCore(query, size)

		}
	} else {
		// 非域名ip类，比如公司名称
		// icp_keywords="xxxx公司"
		//
		if strings.Contains(data, "icp_keywords=") {
			respBody = SearchQuakeCore(data, size)

		} else {
			logger.SlogInfo("[Quake] 查询参数不合法，请检查是否为域名/ip类/公司名称（icp_keywords=\"xxxxx公司\"）")
			return nil, nil
		}
	}

	// quake响应结果处理
	if len(respBody) > 0 {

		if IsVIP {
			logger.SlogInfo("[Quake] VIP用户-数据格式解析")
			// VipQuakeServiceInfo数据格式解析

			var serviceInfo VipQuakeServiceInfo
			err := json.Unmarshal(respBody, &serviceInfo)
			if err != nil {
				logger.SlogInfo("[Quake] 响应解析失败，疑似Token失效、。Quake接口具体返回信息如下：")
				logger.SlogInfo(string(respBody))
				return nil, nil
			}
			for _, d := range serviceInfo.Data {
				if d.Service.HTTP.URL == nil {
					op.Log(fmt.Sprintf("[Quake] %s:%d", d.IP, d.Port))

					assetHttp := types.AssetOther{
						Time: d.Time.Format("2006-01-02 15:04:05"),
						Type: "other",
						Port: strconv.Itoa(d.Port),
						Host: d.Hostname,
						IP:   d.IP,
						Tags: []string{"QUAKE"},
					}

					icp := d.Service.HTTP.Icp.MainLicence.Unit
					if icp != "" {
						assetHttp.Tags = append(assetHttp.Tags, fmt.Sprintf("icp:%v", icp))
					}
					op.ResultFunc(assetHttp)
				} else {
					// op.Log(fmt.Sprintf("%s:%d", d.IP, d.Port))
					for _, url := range d.Service.HTTP.URL {
						op.Log(fmt.Sprintf("[Quake] %s", url))

						url_load_tmp := types.UrlResult{
							Input:  data,
							Source: "quake",
							Status: d.Service.HTTP.StatusCode,
							Output: url,
							Length: 0,
							Tags:   []string{"QUAKE"},
							Time:   d.Time.Format("2006-01-02 15:04:05"),
						}
						url_load_tmp.TaskName = op.TaskName
						hash := utils.Tools.GenerateHash()
						url_load_tmp.ResultId = hash
						go results.Handler.URL(&url_load_tmp)

						op.ResultFunc(url_load_tmp)
					}

					ip := d.IP
					port := d.Port
					protocol := d.Service.Name
					title := d.Service.HTTP.Title
					url := d.Service.HTTP.URL[0]
					icp := d.Service.HTTP.Icp.MainLicence.Unit
					resp := d.Service.Response

					// op.Log(fmt.Sprintf("[Quake]  %s", url))

					assetHttp := types.AssetHttp{
						Time:         d.Time.Format("2006-01-02 15:04:05"),
						Type:         "http",
						Port:         strconv.Itoa(port),
						IP:           ip,
						Title:        title,
						StatusCode:   d.Service.HTTP.StatusCode,
						URL:          url,
						Service:      protocol,
						ResponseBody: resp,
						Tags:         []string{"QUAKE"},
					}
					assetHttp.Host = d.Service.HTTP.Host
					if icp != "" {
						assetHttp.Tags = append(assetHttp.Tags, fmt.Sprintf("icp:%v", icp))
					}
					op.ResultFunc(assetHttp)

				}
				// 构建子域名
				subdomain := types.SubdomainResult{
					Host: d.Service.HTTP.Host,
					IP:   []string{d.IP},
					Tags: []string{"QUAKE"},
				}
				op.ResultFunc(subdomain)

				// 构建端口信息
				domainSkip := types.PortAlive{
					Host: d.Service.HTTP.Host,
					IP:   d.IP,
					Port: strconv.Itoa(d.Port),
				}
				op.ResultFunc(domainSkip)

			}
		} else {
			logger.SlogInfo("[Quake] 普通用户-数据格式解析")
			// CommonQuakeServiceInfo数据格式解析
			var serviceInfo CommonQuakeServiceInfo
			err := json.Unmarshal(respBody, &serviceInfo)
			if err != nil {
				logger.SlogInfo("[Quake] 响应解析失败，疑似Token失效、。Quake接口具体返回信息如下：")
				logger.SlogInfo(string(respBody))
				return nil, nil
			}
			for _, d := range serviceInfo.Data {

				op.Log(fmt.Sprintf("[Quake] %s:%d", d.IP, d.Port))

				if d.Service.Name == "http" || d.Service.Name == "http/ssl" {
					ip := d.IP
					port := d.Port
					var protocol string = ""
					title := d.Service.HTTP.Title
					if d.Service.Name == "http" {
						protocol = "http"
					} else if d.Service.Name == "http/ssl" {
						protocol = "https"
					}
					var tmp_url string = ""
					if d.Service.HTTP.Host != "" {
						tmp_url = protocol + "://" + d.Service.HTTP.Host + ":" + strconv.Itoa(port) + "/"
					} else {
						tmp_url = protocol + "://" + d.IP + ":" + strconv.Itoa(port) + "/"
					}
					resp := d.Service.Response
					op.Log(fmt.Sprintf("[Quake] %s", tmp_url))

					assetHttp := types.AssetHttp{
						Time:         d.Time.Format("2006-01-02 15:04:05"),
						Type:         "http",
						Port:         strconv.Itoa(port),
						IP:           ip,
						Host:         d.Service.HTTP.Host,
						Domain:       d.Service.HTTP.Host,
						StatusCode:   d.Service.HTTP.StatusCode,
						Title:        title,
						URL:          tmp_url,
						Service:      d.Service.Name,
						ResponseBody: resp,
						Tags:         []string{"QUAKE"},
					}
					op.ResultFunc(assetHttp)
				} else {
					assetOther := types.AssetOther{
						Time: d.Time.Format("2006-01-02 15:04:05"),
						Type: "other",
						Port: strconv.Itoa(d.Port),
						Host: d.Domain,
						IP:   d.IP,
						Tags: []string{"QUAKE"},
					}

					op.ResultFunc(assetOther)
				}
				// 构建子域名
				subdomain := types.SubdomainResult{
					Host: d.Service.HTTP.Host,
					IP:   []string{d.IP},
					Tags: []string{"QUAKE"},
				}
				op.ResultFunc(subdomain)

				// 构建端口信息
				domainSkip := types.PortAlive{
					Host: d.Service.HTTP.Host,
					IP:   d.IP,
					Port: strconv.Itoa(d.Port),
				}
				op.ResultFunc(domainSkip)

			}
		}

	} else {
		logger.SlogInfo("quake query error:")
		return nil, nil

	}

	return nil, nil
}

func getQuakeKeys() []string {
	// var apiKeys []string
	apiKeys := APIKEY
	return apiKeys
}

// 从Quake中搜索目标
func SearchQuakeCore(keyword string, pageSize int) []byte {
	// opts := retryablehttp.DefaultOptionsSpraying
	// client := retryablehttp.NewClient(opts)

	url := "https://quake.360.net/api/v3/search/quake_service"
	keys := getQuakeKeys()
	randKey := keys[rand.Intn(len(keys))]

	data := make(map[string]interface{})
	data["query"] = keyword
	data["start"] = "0"
	data["size"] = strconv.Itoa(pageSize)
	// if !IsVIP {
	// 	data["include"] = []string{"ip", "port"}
	// }

	jsonData, _ := json.Marshal(data)
	// QuakeToken := "X-QuakeToken:" + randKey

	// headers := []string{QuakeToken}

	var nullbyte []byte

	// 随机延迟
	rand.Seed(time.Now().UnixNano())
	randNum := rand.Intn(10) + 5
	time.Sleep(time.Second * time.Duration(randNum))
	// 确保不会超速
	// time.Sleep(time.Second * 2)

	// 创建一个 HTTP 请求
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		fmt.Printf(" [Quake] 创建请求失败: %v\n", err)
		return nullbyte
	}

	// 设置请求头
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("X-QuakeToken", randKey)

	// 发起 HTTP 请求并获取响应
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		fmt.Printf("发送请求失败: %v\n", err)
		return nullbyte
	}
	defer resp.Body.Close()

	// 读取响应体

	// 打印响应状态码和内容
	// fmt.Println("状态码:", resp.StatusCode)
	// fmt.Println("响应体:", string(respBody))

	// _, resp := utils.Requests.HttpPostWithCustomHeader(url, jsonData, "json", headers)

	// resp, errDo := client.Do(req)
	// if errDo != nil {
	// 	logger.SlogInfo(fmt.Sprintf("[Quake] [%s] 资产查询失败！请检查网络状态。Error:%s", keyword, errDo.Error()))
	// 	return nullbyte
	// }

	logger.SlogInfo(fmt.Sprintf("[Quake] 状态码：%v", resp.StatusCode))
	if resp.StatusCode == 401 {
		logger.SlogInfo("[Quake] API-KEY错误。请检查。")
		return nullbyte
	} else {
		respBody, err := ioutil.ReadAll(resp.Body)
		if err != nil {
			logger.SlogInfo(fmt.Sprintf("读取响应体失败: %v\n", err))
			return nullbyte
		}
		logger.SlogInfo((fmt.Sprintf("[Quake] [%s] 资产查询成功！返回数据长度：%d", keyword, len(respBody))))
		return respBody
	}

}
